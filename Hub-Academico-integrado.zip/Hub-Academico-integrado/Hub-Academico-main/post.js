// Página de uma publicação, com curtir, salvar e comentários (dados vêm do banco).
(function () {
    "use strict";
    var el = Hub.el;
    var box = document.getElementById("conteudo");
    var id = new URLSearchParams(location.search).get("id");

    function naoEncontrada() {
        box.innerHTML = "";
        box.appendChild(Hub.estadoVazio("🔎", "Publicação não encontrada", "Ela pode ter sido excluída."));
        var a = el("a", "botao-primario", "Voltar ao início"); a.href = "principal.html"; a.style.marginTop = "14px";
        box.appendChild(a);
    }
    if (!id) { naoEncontrada(); return; }

    Hub.detalhe(id).then(function (d) {
        if (!d.post) { naoEncontrada(); return; }
        montar(d.post, d.comentarios);
    }, function (e) { Hub.mostrarErro(box, e); });

    function montar(p, comentarios) {
        document.title = p.titulo + " - Hub Acadêmico";

        var art = el("article", "publicacao publicacao-detalhe");
        art.appendChild(Hub.cabecalhoAutor(p));
        art.appendChild(Hub.etiquetas(p));
        art.appendChild(el("h3", null, p.titulo));
        art.appendChild(el("p", "texto-completo", p.texto));
        art.appendChild(Hub.barraAcoes(p));
        box.appendChild(art);

        var sec = el("section", "comentarios"); sec.id = "comentarios";
        var titulo = el("h2"); sec.appendChild(titulo);
        var lista = el("div"); sec.appendChild(lista);

        function desenha() {
            titulo.textContent = "Comentários (" + comentarios.length + ")";
            lista.innerHTML = "";
            if (!comentarios.length) lista.appendChild(el("p", null, "Ninguém comentou ainda."));
            comentarios.forEach(function (c) {
                var d = el("div", "comentario");
                d.appendChild(el("strong", null, c.autor));
                d.appendChild(el("small", null, " · " + Hub.formatarData(c.ts)));
                if (c.meu) {
                    var x = el("button", "botao-icone", "✕");
                    x.type = "button"; x.title = "Apagar comentário"; x.setAttribute("aria-label", "Apagar comentário");
                    x.addEventListener("click", function () {
                        Hub.excluirComentario(c.id).then(recarregar, function (e) { alert(e.message); });
                    });
                    d.appendChild(x);
                }
                d.appendChild(el("p", null, c.texto));
                lista.appendChild(d);
            });
        }
        function recarregar() {
            Hub.detalhe(p.id).then(function (d) { if (d.post) { comentarios = d.comentarios; desenha(); } },
                function (e) { alert(e.message); });
        }

        if (Hub.logado()) {
            var form = el("form", "formulario-pagina");
            var rot = el("label", null, "Escreva um comentário"); rot.htmlFor = "novoComentario";
            var campo = el("textarea"); campo.id = "novoComentario"; campo.maxLength = 500; campo.placeholder = "Compartilhe sua dúvida ou contribuição...";
            campo.style.minHeight = "80px";
            var enviar = el("button", "botao-primario", "Comentar"); enviar.type = "submit";
            form.append(rot, campo, enviar);
            form.addEventListener("submit", function (e) {
                e.preventDefault();
                var t = campo.value.trim();
                if (!t) return;
                enviar.disabled = true;
                Hub.comentar(p.id, t).then(function () { campo.value = ""; recarregar(); },
                    function (er) { alert(er.message); }).then(function () { enviar.disabled = false; });
            });
            sec.appendChild(form);
        } else {
            var aviso = el("p", null, "Faça login para comentar. ");
            var l = el("a", null, "Entrar"); l.href = "login.html";
            aviso.appendChild(l);
            sec.appendChild(aviso);
        }
        box.appendChild(sec);
        desenha();

        if (p.minha) {
            var ex = el("button", "botao-secundario perigo-botao", "Excluir esta publicação"); ex.type = "button";
            ex.addEventListener("click", function () {
                if (!confirm("Excluir esta publicação?")) return;
                Hub.excluir(p.id).then(function () { location.href = "perfil.html"; }, function (e) { alert(e.message); });
            });
            box.appendChild(ex);
        }
    }
})();
