// Módulo compartilhado do Hub Acadêmico.
// Fala com o servidor (API + PostgreSQL) e monta os cartões de publicação.
// Todas as funções de dados devolvem Promises. O catálogo de matérias (ícones, descrições)
// continua aqui; no banco ficam só o id e o nome de cada matéria.
// Texto vindo do banco sempre entra na tela com textContent (nunca innerHTML).
var Hub = (function () {
    "use strict";

    /* ---------- sessão (token guardado no navegador) ---------- */
    function lerLocal(chave, padrao) {
        try { return localStorage.getItem(chave) || padrao; } catch (e) { return padrao; }
    }
    function gravarLocal(chave, valor) {
        try { localStorage.setItem(chave, valor); } catch (e) { /* sem storage */ }
    }
    var token = lerLocal("token", null);

    function nomeUsuario() { return lerLocal("nome", "Estudante"); }
    function logado() { return !!token; }
    function sairLocal() {
        ["token", "email", "nome"].forEach(function (k) { try { localStorage.removeItem(k); } catch (e) { /* ok */ } });
    }
    // Páginas que só funcionam logado chamam isto no começo; devolve false (e redireciona) se não houver login
    function exigirLogin() {
        if (!token) { location.href = "login.html"; return false; }
        return true;
    }

    /* ---------- chamadas à API ---------- */
    function api(url, opcoes) {
        opcoes = opcoes || {};
        var headers = Object.assign({ "Content-Type": "application/json" }, opcoes.headers || {});
        if (token) headers.Authorization = "Bearer " + token;
        return fetch(url, Object.assign({}, opcoes, { headers: headers })).then(function (resposta) {
            return resposta.json().then(function (dados) { return { resposta: resposta, dados: dados }; },
                function () { throw new Error("Resposta inválida do servidor."); });
        }, function () {
            throw new Error("Não foi possível conectar ao servidor.");
        }).then(function (r) {
            if (r.resposta.status === 401 && token) {
                sairLocal();
                location.href = "login.html";
                throw new Error(r.dados.erro || "Sessão expirada.");
            }
            if (!r.resposta.ok || r.dados.ok === false) throw new Error(r.dados.erro || "Ocorreu um erro.");
            return r.dados;
        });
    }
    function post(url, corpo) { return api(url, { method: "POST", body: JSON.stringify(corpo || {}) }); }
    function apagar(url) { return api(url, { method: "DELETE" }); }

    function sair(destino) {
        var fim = function () { sairLocal(); location.href = destino || "hub.html"; };
        if (!token) return fim();
        return api("/api/logout", { method: "POST" }).then(fim, fim);
    }

    /* ---------- catálogo ---------- */
    var CATEGORIAS = [
        { nome: "Materiais de estudo", curto: "Materiais" },
        { nome: "Estágios", curto: "Estágios" },
        { nome: "Grupos", curto: "Grupos" },
        { nome: "Eventos", curto: "Eventos" },
        { nome: "Avisos", curto: "Avisos" }
    ];

    var AREAS = ["Computação", "Exatas", "Gestão e Humanas"];

    var MATERIAS = [
        { id: "bd", area: "Computação", icone: "🗄️", nome: "Banco de Dados",
          desc: "Modelagem, SQL e normalização.", topicos: ["SQL", "Modelagem ER", "Normalização"] },
        { id: "prog", area: "Computação", icone: "☕", nome: "Programação (Java e POO)",
          desc: "Lógica, Java e orientação a objetos.", topicos: ["Java", "Herança", "Polimorfismo"] },
        { id: "ed", area: "Computação", icone: "🌳", nome: "Estruturas de Dados",
          desc: "Listas, árvores, grafos e algoritmos.", topicos: ["Árvores", "Grafos", "Ordenação"] },
        { id: "redes", area: "Computação", icone: "🌐", nome: "Redes de Computadores",
          desc: "Modelo OSI, TCP/IP e endereçamento.", topicos: ["OSI x TCP/IP", "Sub-redes", "Protocolos"] },
        { id: "es", area: "Computação", icone: "🧩", nome: "Engenharia de Software",
          desc: "Requisitos, UML, métodos ágeis e testes.", topicos: ["UML", "Scrum", "Testes"] },
        { id: "so", area: "Computação", icone: "⚙️", nome: "Sistemas Operacionais",
          desc: "Processos, memória e escalonamento.", topicos: ["Processos", "Escalonamento", "Memória"] },
        { id: "calc", area: "Exatas", icone: "📈", nome: "Cálculo",
          desc: "Limites, derivadas e integrais.", topicos: ["Limites", "Derivadas", "Integrais"] },
        { id: "alg", area: "Exatas", icone: "🧮", nome: "Álgebra Linear",
          desc: "Matrizes, vetores e autovalores.", topicos: ["Matrizes", "Espaços vetoriais", "Autovalores"] },
        { id: "est", area: "Exatas", icone: "📊", nome: "Estatística e Probabilidade",
          desc: "Probabilidade, distribuições e inferência.", topicos: ["Probabilidade", "Distribuições", "Testes"] },
        { id: "fis", area: "Exatas", icone: "🔭", nome: "Física",
          desc: "Mecânica, eletromagnetismo e ondas.", topicos: ["Mecânica", "Eletromagnetismo", "Ondas"] },
        { id: "ing", area: "Gestão e Humanas", icone: "🗣️", nome: "Inglês Técnico",
          desc: "Leitura de artigos e vocabulário da área.", topicos: ["Vocabulário", "Leitura", "Conversação"] },
        { id: "met", area: "Gestão e Humanas", icone: "🔬", nome: "Metodologia Científica",
          desc: "Projetos, normas ABNT e TCC.", topicos: ["ABNT", "TCC", "Pesquisa"] }
    ];

    /* ---------- utilidades ---------- */
    function el(tag, classe, texto) {
        var e = document.createElement(tag);
        if (classe) e.className = classe;
        if (texto !== undefined) e.textContent = texto;
        return e;
    }
    function iniciais(nome) {
        var p = String(nome).replace(/^(Prof\.|Profa\.)\s*/, "").trim().split(/\s+/);
        return ((p[0] || "?")[0] + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase();
    }
    function materia(id) {
        for (var i = 0; i < MATERIAS.length; i++) if (MATERIAS[i].id === id) return MATERIAS[i];
        return null;
    }
    function hhmm(d) { return ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2); }
    function inicioDia(d) { return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); }
    function diasAtras(ts) { return Math.round((inicioDia(new Date()) - inicioDia(new Date(ts))) / 86400000); }
    function formatarData(ts) {
        var d = new Date(ts), n = diasAtras(ts);
        if (n <= 0) return "Hoje às " + hhmm(d);
        if (n === 1) return "Ontem às " + hhmm(d);
        return d.toLocaleDateString("pt-BR") + " às " + hhmm(d);
    }
    function grupoDia(ts) {
        var n = diasAtras(ts);
        if (n <= 0) return "Hoje";
        if (n === 1) return "Ontem";
        if (n < 7) return "Esta semana";
        return "Mais antigas";
    }

    /* ---------- publicações ---------- */
    // Converte uma linha do servidor no formato usado pelas telas
    function normaliza(t) {
        return {
            id: t.id, autor: t.autor, papel: t.papel || "Aluno", minha: !!t.meu,
            categoria: t.categoria, materia: t.materia || null,
            titulo: t.titulo, texto: t.conteudo, ts: new Date(t.criado_em).getTime(),
            curtidas: t.curtidas || 0, comentarios: t.comentarios || 0,
            curtido: !!t.curtido, salvo: !!t.salvo
        };
    }
    function pontuacao(p) { return p.curtidas + p.comentarios * 2; }

    function todos() {
        return api("/api/topicos?limite=500").then(function (d) { return d.topicos.map(normaliza); });
    }
    function meus() {
        return api("/api/topicos?meus=1&limite=500").then(function (d) { return d.topicos.map(normaliza); });
    }
    function salvos() {
        return api("/api/salvos").then(function (d) { return d.salvos.map(normaliza); });
    }
    // Uma publicação com seus comentários: { post, comentarios } (post = null se não existir)
    function detalhe(id) {
        return api("/api/topicos/" + encodeURIComponent(id)).then(function (d) {
            return {
                post: normaliza(d.topico),
                comentarios: d.comentarios.map(function (c) {
                    return { id: c.id, autor: c.autor, papel: c.papel || "Aluno", texto: c.conteudo, ts: new Date(c.criado_em).getTime(), meu: !!c.meu };
                })
            };
        }, function (e) {
            if (/não encontrado|inválido/i.test(e.message)) return { post: null, comentarios: [] };
            throw e;
        });
    }
    // dados: { titulo, categoria (nome), materia (id ou null), texto, rascunhoId? }
    function publicar(dados) {
        return post("/api/topicos", {
            titulo: dados.titulo, categoria: dados.categoria, materia_id: dados.materia || null,
            conteudo: dados.texto, rascunho_id: dados.rascunhoId || null
        }).then(function (d) {
            gravarLocal("hubUltimoId", String(d.id));
            return d.id;
        });
    }
    function excluir(id) { return apagar("/api/topicos/" + encodeURIComponent(id)); }

    /* ---------- rascunhos ---------- */
    function normalizaRascunho(r) {
        return { id: r.id, titulo: r.titulo || "", categoria: r.categoria || "Materiais de estudo",
                 materia: r.materia || null, texto: r.conteudo || "", ts: new Date(r.atualizado_em).getTime() };
    }
    function rascunhos() {
        return api("/api/rascunhos").then(function (d) { return d.rascunhos.map(normalizaRascunho); });
    }
    function rascunho(id) {
        return api("/api/rascunhos/" + encodeURIComponent(id)).then(function (d) { return normalizaRascunho(d.rascunho); },
            function () { return null; });
    }
    // dados: { id?, titulo, categoria, materia, texto }
    function salvarRascunho(dados) {
        return post("/api/rascunhos", {
            id: dados.id || null, titulo: dados.titulo, categoria: dados.categoria,
            materia_id: dados.materia || null, conteudo: dados.texto
        }).then(function (d) { return d.id; });
    }
    function excluirRascunho(id) { return apagar("/api/rascunhos/" + encodeURIComponent(id)); }

    /* ---------- comentários ---------- */
    function comentar(id, texto) {
        return post("/api/topicos/" + encodeURIComponent(id) + "/comentarios", { conteudo: texto });
    }
    function excluirComentario(id) { return apagar("/api/comentarios/" + encodeURIComponent(id)); }

    /* ---------- cartões ---------- */
    function cabecalhoAutor(p) {
        var u = el("div", "usuario");
        u.appendChild(el("div", "avatar" + (p.papel === "Professor" ? " professor" : ""), iniciais(p.autor)));
        var info = el("div");
        info.appendChild(el("strong", null, p.autor + " · " + p.papel));
        info.appendChild(el("small", null, formatarData(p.ts)));
        u.appendChild(info);
        if (p.minha) u.appendChild(el("span", "selo-voce", "Você"));
        return u;
    }
    function etiquetas(p) {
        var box = el("div", "etiquetas");
        box.appendChild(el("span", "categoria-post" + (p.categoria === "Avisos" ? " aviso" : ""), p.categoria));
        var m = materia(p.materia);
        if (m) {
            var a = el("a", "categoria-post materia-chip", m.icone + " " + m.nome);
            a.href = "materiais.html?materia=" + m.id;
            box.appendChild(a);
        }
        return box;
    }
    function cartao(p) {
        var art = el("article", "publicacao");
        art.appendChild(cabecalhoAutor(p));
        art.appendChild(etiquetas(p));
        var h = el("h3");
        var link = el("a", "titulo-link", p.titulo);
        link.href = "publicacao.html?id=" + encodeURIComponent(p.id);
        h.appendChild(link);
        art.appendChild(h);
        art.appendChild(el("p", null, p.texto.length > 160 ? p.texto.slice(0, 157).trim() + "…" : p.texto));
        art.appendChild(barraAcoes(p));
        return art;
    }
    function barraAcoes(p) {
        var acoes = el("div", "acoes");
        p = Object.assign({}, p);

        var bc = el("button");
        bc.type = "button";
        function pintaCurtir() {
            bc.textContent = (p.curtido ? "♥ " : "♡ ") + p.curtidas;
            bc.className = p.curtido ? "ativo" : "";
            bc.setAttribute("aria-pressed", p.curtido ? "true" : "false");
            bc.setAttribute("aria-label", p.curtido ? "Remover curtida" : "Curtir");
        }
        pintaCurtir();
        bc.addEventListener("click", function () {
            if (!token) { alert("Faça login para curtir uma publicação."); return; }
            post("/api/topicos/" + encodeURIComponent(p.id) + "/curtir").then(function (r) {
                p.curtidas += r.curtido ? 1 : -1;
                p.curtido = r.curtido;
                pintaCurtir();
            }, function (e) { alert(e.message); });
        });

        var cm = el("a", null, "💬 " + p.comentarios);
        cm.href = "publicacao.html?id=" + encodeURIComponent(p.id) + "#comentarios";
        cm.setAttribute("aria-label", "Ver comentários");

        var bs = el("button", null, "🔖");
        bs.type = "button";
        function pintaSalvo() {
            bs.className = "salvar" + (p.salvo ? " ativo" : "");
            bs.setAttribute("aria-pressed", p.salvo ? "true" : "false");
            bs.setAttribute("aria-label", p.salvo ? "Remover dos salvos" : "Salvar");
            bs.textContent = p.salvo ? "🔖 Salvo" : "🔖";
        }
        pintaSalvo();
        bs.addEventListener("click", function () {
            if (!token) { alert("Faça login para salvar uma publicação."); return; }
            post("/api/topicos/" + encodeURIComponent(p.id) + "/salvar").then(function (r) {
                p.salvo = r.salvo;
                pintaSalvo();
            }, function (e) { alert(e.message); });
        });

        acoes.append(bc, cm, bs);
        return acoes;
    }

    function estadoVazio(icone, titulo, texto) {
        var d = el("div", "estado-vazio");
        d.appendChild(document.createTextNode(icone));
        d.appendChild(document.createElement("br"));
        d.appendChild(el("strong", null, titulo));
        d.appendChild(document.createElement("br"));
        d.appendChild(document.createTextNode(texto));
        return d;
    }
    // Mensagem de erro de carregamento dentro de um container
    function mostrarErro(container, erro) {
        container.innerHTML = "";
        container.appendChild(estadoVazio("⚠️", "Não foi possível carregar", erro && erro.message ? erro.message : "Tente novamente."));
    }

    return {
        CATEGORIAS: CATEGORIAS, AREAS: AREAS, MATERIAS: MATERIAS,
        api: api, logado: logado, exigirLogin: exigirLogin, sair: sair, nomeUsuario: nomeUsuario,
        el: el, materia: materia, formatarData: formatarData, grupoDia: grupoDia, iniciais: iniciais,
        todos: todos, meus: meus, salvos: salvos, detalhe: detalhe, pontuacao: pontuacao,
        publicar: publicar, excluir: excluir,
        rascunhos: rascunhos, rascunho: rascunho, salvarRascunho: salvarRascunho, excluirRascunho: excluirRascunho,
        comentar: comentar, excluirComentario: excluirComentario,
        ultimoId: function () { return lerLocal("hubUltimoId", null); },
        cartao: cartao, barraAcoes: barraAcoes, cabecalhoAutor: cabecalhoAutor, etiquetas: etiquetas,
        estadoVazio: estadoVazio, mostrarErro: mostrarErro
    };
})();
