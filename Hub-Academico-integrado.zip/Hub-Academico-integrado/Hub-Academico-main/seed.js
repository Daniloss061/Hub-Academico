// Popula o banco com as publicações de exemplo do Hub (opcional).
// Uso: npm run seed     (precisa do banco configurado no .env)
// Cria usuários fictícios SEM senha utilizável (ninguém consegue entrar com eles).
// É seguro rodar várias vezes: não duplica usuários nem publicações.
require("dotenv").config();

const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");

const pool = new Pool({
    host: process.env.DB_HOST || "localhost",
    port: Number(process.env.DB_PORT) || 5432,
    database: process.env.DB_NAME || "hub_academico",
    user: process.env.DB_USER || "postgres",
    password: process.env.DB_PASSWORD
});

// horas = quantas horas atrás foi publicado
const EXEMPLOS = [
    { id: "s1", autor: "João", papel: "Aluno", categoria: "Materiais de estudo", materia: "bd", horas: 2, curtidas: 12, comentarios: 3,
      titulo: "Material de Banco de Dados", texto: "Estou compartilhando um material que me ajudou a estudar SQL." },
    { id: "s2", autor: "Prof. Carlos", papel: "Professor", categoria: "Avisos", materia: "prog", horas: 3, curtidas: 15, comentarios: 2,
      titulo: "Lista de exercícios de Java", texto: "Lista complementar para praticar programação orientada a objetos." },
    { id: "s3", autor: "Marina", papel: "Aluna", categoria: "Materiais de estudo", materia: "calc", horas: 4, curtidas: 24, comentarios: 6,
      titulo: "Resumo de derivadas e regra da cadeia", texto: "Resumo de uma página com as regras de derivação e exemplos resolvidos passo a passo." },
    { id: "s4", autor: "Monitoria de Redes", papel: "Monitor", categoria: "Eventos", materia: "redes", horas: 6, curtidas: 9, comentarios: 1,
      titulo: "Plantão de dúvidas: sub-redes e CIDR", texto: "Quinta-feira, às 18h, no laboratório 3. Traga os exercícios da lista para resolvermos juntos." },
    { id: "s5", autor: "Coordenação", papel: "Coordenação", categoria: "Avisos", materia: null, horas: 8, curtidas: 31, comentarios: 8,
      titulo: "Prazo de entrega das atividades complementares", texto: "O prazo para envio dos certificados termina no dia 30. Envie pelo sistema acadêmico." },
    { id: "s6", autor: "Rafael", papel: "Aluno", categoria: "Estágios", materia: null, horas: 22, curtidas: 18, comentarios: 5,
      titulo: "Vaga de estágio em desenvolvimento web", texto: "Empresa de software procura estagiário (HTML, CSS e JavaScript). Meio período, remoto." },
    { id: "s7", autor: "Profa. Helena", papel: "Professor", categoria: "Materiais de estudo", materia: "est", horas: 26, curtidas: 14, comentarios: 2,
      titulo: "Lista de probabilidade com gabarito", texto: "Exercícios sobre probabilidade condicional e Bayes, com respostas comentadas." },
    { id: "s8", autor: "Bianca", papel: "Aluna", categoria: "Grupos", materia: "es", horas: 28, curtidas: 7, comentarios: 4,
      titulo: "Grupo para o projeto de Engenharia de Software", texto: "Faltam duas pessoas para fechar nosso grupo. Quem curte front-end e testes?" },
    { id: "s9", autor: "Lucas", papel: "Aluno", categoria: "Materiais de estudo", materia: "ed", horas: 30, curtidas: 40, comentarios: 9,
      titulo: "Cheatsheet: árvores e grafos", texto: "Complexidades, percursos (BFS/DFS) e quando usar cada estrutura, tudo em um PDF." },
    { id: "s10", autor: "Centro Acadêmico", papel: "Entidade", categoria: "Eventos", materia: null, horas: 48, curtidas: 52, comentarios: 12,
      titulo: "Semana de Tecnologia: inscrições abertas", texto: "Palestras, minicursos e feira de projetos. Inscrições gratuitas até sexta-feira." },
    { id: "s11", autor: "Camila", papel: "Aluna", categoria: "Materiais de estudo", materia: "so", horas: 50, curtidas: 16, comentarios: 3,
      titulo: "Escalonamento de processos explicado", texto: "FCFS, SJF e Round Robin com diagramas de Gantt e exemplos numéricos." },
    { id: "s12", autor: "Prof. Marcos", papel: "Professor", categoria: "Materiais de estudo", materia: "alg", horas: 72, curtidas: 21, comentarios: 5,
      titulo: "Videoaula: autovalores e autovetores", texto: "Gravação da aula com a intuição geométrica e dois exemplos de diagonalização." },
    { id: "s13", autor: "Thiago", papel: "Aluno", categoria: "Grupos", materia: "ing", horas: 78, curtidas: 11, comentarios: 2,
      titulo: "Grupo de conversação em inglês técnico", texto: "Encontros semanais para treinar apresentação de projetos e leitura de documentação." },
    { id: "s14", autor: "Profa. Ana", papel: "Professor", categoria: "Avisos", materia: "met", horas: 100, curtidas: 19, comentarios: 3,
      titulo: "Modelo de projeto de TCC atualizado", texto: "O novo modelo segue a ABNT mais recente. Baixe no ambiente virtual antes de iniciar o texto." },
    { id: "s15", autor: "Gustavo", papel: "Aluno", categoria: "Estágios", materia: null, horas: 120, curtidas: 27, comentarios: 7,
      titulo: "Como montar um portfólio no GitHub", texto: "Dicas de README, organização de repositórios e quais projetos destacar para recrutadores." },
    { id: "s16", autor: "Débora", papel: "Aluna", categoria: "Materiais de estudo", materia: "fis", horas: 150, curtidas: 13, comentarios: 1,
      titulo: "Resolução de Física: eletromagnetismo", texto: "Resolvi a lista 4 (lei de Gauss e potencial elétrico). Se achar erro, comenta!" },
    { id: "s17", autor: "Prof. Carlos", papel: "Professor", categoria: "Materiais de estudo", materia: "bd", horas: 170, curtidas: 33, comentarios: 6,
      titulo: "Slides: normalização (1FN a 3FN)", texto: "Slides da aula com exemplos de dependências funcionais e como chegar à terceira forma normal." },
    { id: "s18", autor: "Pedro", papel: "Aluno", categoria: "Materiais de estudo", materia: "prog", horas: 200, curtidas: 22, comentarios: 4,
      titulo: "Exemplos de herança e polimorfismo em Java", texto: "Repositório com exemplos comentados de classes abstratas, interfaces e sobrescrita." },
    { id: "s19", autor: "Letícia", papel: "Aluna", categoria: "Materiais de estudo", materia: "es", horas: 210, curtidas: 17, comentarios: 2,
      titulo: "Diagramas UML: guia rápido", texto: "Casos de uso, classes e sequência resumidos com um exemplo de sistema de biblioteca." },
    { id: "s20", autor: "Ana", papel: "Aluna", categoria: "Materiais de estudo", materia: "redes", horas: 230, curtidas: 25, comentarios: 3,
      titulo: "Modelo OSI x TCP/IP: resumo", texto: "Tabela comparativa das camadas, protocolos de cada uma e perguntas frequentes de prova." }
];

const slug = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, ".").replace(/^\.|\.$/g, "");

async function main() {
    await pool.query(fs.readFileSync(path.join(__dirname, "banco.sql"), "utf8"));
    const cats = await pool.query("SELECT id, nome FROM categorias");
    const catId = Object.fromEntries(cats.rows.map((c) => [c.nome, c.id]));
    let novos = 0;

    for (const p of EXEMPLOS) {
        const email = slug(p.autor) + "@exemplo.hub";
        const u = await pool.query(
            `INSERT INTO usuarios (email, senha_hash, nome, papel)
             VALUES ($1, '!', $2, $3)
             ON CONFLICT (email) DO UPDATE SET nome = EXCLUDED.nome
             RETURNING id`,
            [email, p.autor, p.papel]
        );
        const r = await pool.query(
            `INSERT INTO topicos (usuario_id, categoria_id, materia_id, titulo, conteudo, criado_em)
             SELECT $1::int, $2::int, $3::varchar, $4::varchar, $5::text, NOW() - ($6::text || ' hours')::interval
              WHERE NOT EXISTS (SELECT 1 FROM topicos WHERE usuario_id = $1::int AND titulo = $4::varchar)`,
            [u.rows[0].id, catId[p.categoria], p.materia, p.titulo, p.texto, String(p.horas)]
        );
        novos += r.rowCount;
    }
    console.log(`Pronto: ${novos} publicação(ões) de exemplo inserida(s) (${EXEMPLOS.length - novos} já existiam).`);
}

main()
    .catch((e) => { console.error("Erro no seed:", e.message); process.exitCode = 1; })
    .finally(() => pool.end());
