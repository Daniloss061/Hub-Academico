# Hub Acadêmico

Informação, conhecimento e oportunidade em um só lugar.

Site (HTML/CSS/JS) com servidor Node.js + Express e banco **PostgreSQL**. Contas, publicações, comentários, curtidas, salvos e rascunhos ficam no banco.

## Como rodar

1. Instale o Node.js (versão LTS) e o PostgreSQL.
2. No pgAdmin, crie um banco chamado `hub_academico`.
3. Copie o `.env.example` para `.env` e coloque a senha do seu PostgreSQL em `DB_PASSWORD`.
4. No terminal, dentro desta pasta:

```
npm install
npm start
```

5. Abra http://localhost:3000

As tabelas são criadas sozinhas na primeira vez (veja `banco.sql`).

**Publicações de exemplo (opcional):** `npm run seed` insere as 20 publicações de demonstração (autores fictícios, sem senha). Pode rodar mais de uma vez, não duplica.

> No PowerShell do Windows, se o `npm` for bloqueado, use `npm.cmd install`, `npm.cmd start` e `npm.cmd run seed`.

## Estrutura

| Arquivo | Função |
|---|---|
| `server.js` | servidor e rotas da API |
| `banco.sql` | estrutura do banco (usuários, sessões, categorias, matérias, tópicos, comentários, curtidas, salvos, rascunhos) |
| `seed.js` | publicações de exemplo (opcional) |
| `hub.js` | módulo compartilhado: chamadas à API, sessão, catálogo de matérias e cartões de publicação |
| `hub.html`, `login.html`, `cadastro.html` | entrada, login e criação de conta |
| `principal.html`, `feed.js` | feed com destaques, filtros, ordenação e paginação |
| `publicacao.html`, `post.js` | uma publicação com comentários |
| `nova-publicacao.html`, `nova.js` | criar publicação ou rascunho |
| `materiais.html`, `materias.js` | matérias e materiais por matéria |
| `explorar.html`, `salvos.html`, `perfil.html` (+ `perfil.js`), `editar-perfil.html` | demais telas |
| `style.css` | estilos |

## API

Rotas com login exigem `Authorization: Bearer <token>` (o token fica em `localStorage`).

| Ação | Rota | Login |
|---|---|---|
| Cadastro / Login / Logout | `POST /api/cadastro`, `POST /api/login`, `POST /api/logout` | só o logout |
| Categorias | `GET /api/categorias` | não |
| Listar tópicos | `GET /api/topicos` (`?categoria=ID`, `?busca=`, `?materia=id`, `?meus=1`, `?limite=N` até 500) | opcional (`meus` exige) |
| Ver tópico + comentários | `GET /api/topicos/:id` | opcional |
| Criar tópico | `POST /api/topicos` (`titulo`, `conteudo`, `categoria` ou `categoria_id`, `materia_id`, `rascunho_id`) | sim |
| Apagar tópico / comentário (só o autor) | `DELETE /api/topicos/:id`, `DELETE /api/comentarios/:id` | sim |
| Comentar | `POST /api/topicos/:id/comentarios` | sim |
| Curtir / salvar (alterna) | `POST /api/topicos/:id/curtir`, `POST /api/topicos/:id/salvar` | sim |
| Meus salvos | `GET /api/salvos` | sim |
| Rascunhos | `GET /api/rascunhos`, `GET /api/rascunhos/:id`, `POST /api/rascunhos` (com `id` atualiza), `DELETE /api/rascunhos/:id` | sim |
| Perfil | `GET /api/perfil`, `PUT /api/perfil` (`nome`, `bio`) | sim |

"Materiais de estudo" exige `materia_id`. Ao publicar com `rascunho_id`, o rascunho é removido junto.
