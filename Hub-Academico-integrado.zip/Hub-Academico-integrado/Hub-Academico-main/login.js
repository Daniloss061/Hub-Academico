const formulario = document.getElementById("formLogin");

// Quem já está logado vai direto pro feed
if (localStorage.getItem("token")) window.location.href = "principal.html";

if (formulario) {
    formulario.addEventListener("submit", async function (event) {
        event.preventDefault();

        const email = document.getElementById("email").value.trim();
        const senha = document.getElementById("senha").value;
        const mensagem = document.getElementById("mensagem");

        if (email === "" || senha.trim() === "") {
            mensagem.textContent = "Preencha todos os campos.";
            return;
        }

        try {
            const dados = await Hub.api("/api/login", {
                method: "POST",
                body: JSON.stringify({ email, senha })
            });

            // Guarda o token da sessão para as próximas ações
            localStorage.setItem("token", dados.token);
            localStorage.setItem("email", dados.email);
            localStorage.setItem("nome", dados.nome);

            mensagem.textContent = "Login realizado com sucesso!";
            setTimeout(function () { window.location.href = "principal.html"; }, 500);
        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    });
}
