console.log("PRINCIPAL.JS FOI CARREGADO");

const token = localStorage.getItem("token");
const email = localStorage.getItem("email");

async function requisicao(url, opcoes = {}) {

    const resposta = await fetch(url, {
        ...opcoes,
        headers: {
            "Content-Type": "application/json",
            ...(opcoes.headers || {}),
            ...(token
                ? { "Authorization": `Bearer ${token}` }
                : {})
        }
    });

    let dados;

    try {
        dados = await resposta.json();
    } catch {
        throw new Error("Resposta inválida do servidor.");
    }

    if (!resposta.ok) {
        throw new Error(dados.erro || "Ocorreu um erro.");
    }

    return dados;
}


// =====================================================
// ELEMENTOS DA PÁGINA
// =====================================================

const listaPublicacoes = document.querySelector(".publicacoes");
const listaCategorias = document.querySelector(".lista-categorias");
const campoPesquisa = document.querySelector(".pesquisa input");
const botaoAdicionar = document.querySelector(".botao-adicionar");
const botaoNotificacao = document.querySelector(".notificacao");


// =====================================================
// CARREGAR CATEGORIAS
// =====================================================

async function carregarCategorias() {

    try {

        const dados = await requisicao("/api/categorias");

        listaCategorias.innerHTML = "";

        dados.categorias.forEach((categoria, index) => {

            const div = document.createElement("div");

            div.className = "categoria";

            const icones = ["📚", "💼", "👥", "📅"];

            div.innerHTML = `
                <div class="icone-categoria">
                    ${icones[index] || "📌"}
                </div>

                <span>${categoria.nome}</span>
            `;

            div.addEventListener("click", function () {

                carregarTopicos(categoria.id);

            });

            listaCategorias.appendChild(div);

        });

    } catch (erro) {

        console.error("Erro ao carregar categorias:", erro);

    }
}


// =====================================================
// CARREGAR PUBLICAÇÕES
// =====================================================

async function carregarTopicos(categoriaId = null) {

    try {

        let url = "/api/topicos";

        if (categoriaId) {
            url += `?categoria=${categoriaId}`;
        }

        const dados = await requisicao(url);

        renderizarTopicos(dados.topicos);

    } catch (erro) {

        console.error("Erro ao carregar publicações:", erro);

        listaPublicacoes.innerHTML = `
            <h2>Publicações recentes</h2>
            <p>Não foi possível carregar as publicações.</p>
        `;
    }
}


// =====================================================
// MOSTRAR PUBLICAÇÕES
// =====================================================

function renderizarTopicos(topicos) {

    listaPublicacoes.innerHTML = `
        <h2>Publicações recentes</h2>
    `;

    if (topicos.length === 0) {

        listaPublicacoes.innerHTML += `
            <p>Nenhuma publicação encontrada.</p>
        `;

        return;
    }

    topicos.forEach(topico => {

        const publicacao = document.createElement("article");

        publicacao.className = "publicacao";

        publicacao.innerHTML = `

            <div class="usuario">

                <div class="avatar">
                    ${topico.autor.charAt(0).toUpperCase()}
                </div>

                <div>
                    <strong>${topico.autor}</strong>

                    <small>
                        ${formatarData(topico.criado_em)}
                    </small>
                </div>

                <span class="mais">
                    •••
                </span>

            </div>

            <span class="categoria-post">
                ${topico.categoria}
            </span>

            <h3>
                ${topico.titulo}
            </h3>

            <p>
                ${topico.conteudo}
            </p>

            <div class="acoes">

                <button class="botao-curtir">
                    ♡ ${topico.curtidas}
                </button>

                <button class="botao-comentarios">
                    💬 ${topico.comentarios}
                </button>

                <button class="botao-salvar">
                    🔖
                </button>

            </div>
        `;


        // CURTIR
        const botaoCurtir =
            publicacao.querySelector(".botao-curtir");

        botaoCurtir.addEventListener("click", async function () {

            if (!token) {

                alert("Faça login para curtir uma publicação.");

                return;
            }

            try {

                await requisicao(
                    `/api/topicos/${topico.id}/curtir`,
                    {
                        method: "POST"
                    }
                );

                carregarTopicos();

            } catch (erro) {

                alert(erro.message);

            }

        });


        // COMENTÁRIOS
        const botaoComentarios =
            publicacao.querySelector(".botao-comentarios");

        botaoComentarios.addEventListener("click", async function () {

            const comentario = prompt(
                "Digite seu comentário:"
            );

            if (!comentario || comentario.trim() === "") {
                return;
            }

            try {

                await requisicao(
                    `/api/topicos/${topico.id}/comentarios`,
                    {
                        method: "POST",
                        body: JSON.stringify({
                            conteudo: comentario
                        })
                    }
                );

                carregarTopicos();

            } catch (erro) {

                alert(erro.message);

            }

        });


        // SALVAR
        const botaoSalvar =
            publicacao.querySelector(".botao-salvar");

        botaoSalvar.addEventListener("click", async function () {

            if (!token) {

                alert("Faça login para salvar uma publicação.");

                return;
            }

            try {

                await requisicao(
                    `/api/topicos/${topico.id}/salvar`,
                    {
                        method: "POST"
                    }
                );

                alert("Publicação salva!");

            } catch (erro) {

                alert(erro.message);

            }

        });


        listaPublicacoes.appendChild(publicacao);

    });

}


// =====================================================
// PESQUISA
// =====================================================

campoPesquisa.addEventListener("input", async function () {

    const texto = campoPesquisa.value
        .trim()
        .toLowerCase();

    if (texto === "") {

        carregarTopicos();

        return;
    }

    try {

        const dados = await requisicao("/api/topicos");

        const resultados = dados.topicos.filter(topico =>

            topico.titulo.toLowerCase().includes(texto) ||
            topico.conteudo.toLowerCase().includes(texto) ||
            topico.categoria.toLowerCase().includes(texto) ||
            topico.autor.toLowerCase().includes(texto)

        );

        renderizarTopicos(resultados);

    } catch (erro) {

        console.error(erro);

    }

});


// =====================================================
// NOVA PUBLICAÇÃO
// =====================================================

botaoAdicionar.addEventListener("click", async function () {

    if (!token) {

        alert("Faça login para criar uma publicação.");

        return;
    }

    try {

        const dadosCategorias =
            await requisicao("/api/categorias");

        const titulo = prompt(
            "Digite o título da publicação:"
        );

        if (!titulo || titulo.trim() === "") {
            return;
        }

        const conteudo = prompt(
            "Digite o conteúdo da publicação:"
        );

        if (!conteudo || conteudo.trim() === "") {
            return;
        }

        let lista = "";

        dadosCategorias.categorias.forEach(categoria => {

            lista +=
                `${categoria.id} - ${categoria.nome}\n`;

        });

        const escolha = prompt(
            `Escolha a categoria digitando o ID:\n\n${lista}`
        );

        const categoriaId = Number(escolha);

        if (!categoriaId) {

            alert("Categoria inválida.");

            return;
        }

        await requisicao("/api/topicos", {

            method: "POST",

            body: JSON.stringify({

                titulo: titulo,

                conteudo: conteudo,

                categoria_id: categoriaId

            })

        });

        alert("Publicação criada com sucesso!");

        carregarTopicos();

    } catch (erro) {

        alert(erro.message);

    }

});


// =====================================================
// NOTIFICAÇÕES
// =====================================================

botaoNotificacao.addEventListener("click", function () {

    alert("Você não possui novas notificações.");

});


// =====================================================
// MENU INFERIOR
// =====================================================

const menuLinks = document.querySelectorAll(".menu a");

menuLinks.forEach((link, index) => {

    link.addEventListener("click", async function (event) {

        event.preventDefault();

        if (index === 0) {

            carregarTopicos();

        }

        else if (index === 1) {

            campoPesquisa.focus();

        }

        else if (index === 2) {

            carregarSalvos();

        }

        else if (index === 3) {

            mostrarPerfil();

        }

    });

});


// =====================================================
// PUBLICAÇÕES SALVAS
// =====================================================

async function carregarSalvos() {

    if (!token) {

        alert("Faça login para visualizar seus salvos.");

        return;
    }

    try {

        const dados = await requisicao("/api/salvos");

        listaPublicacoes.innerHTML = `
            <h2>Publicações salvas</h2>
        `;

        if (dados.salvos.length === 0) {

            listaPublicacoes.innerHTML += `
                <p>Você ainda não salvou nenhuma publicação.</p>
            `;

            return;
        }

        dados.salvos.forEach(salvo => {

            const artigo =
                document.createElement("article");

            artigo.className = "publicacao";

            artigo.innerHTML = `

                <span class="categoria-post">
                    ${salvo.categoria}
                </span>

                <h3>
                    ${salvo.titulo}
                </h3>

                <small>
                    Salvo em ${formatarData(salvo.salvo_em)}
                </small>

            `;

            listaPublicacoes.appendChild(artigo);

        });

    } catch (erro) {

        alert(erro.message);

    }

}


// =====================================================
// PERFIL
// =====================================================

function mostrarPerfil() {

    const opcao = confirm(
        `Perfil\n\nE-mail: ${email || "não identificado"}\n\nDeseja sair da conta?`
    );

    if (!opcao) {
        return;
    }

    fazerLogout();

}


// =====================================================
// LOGOUT
// =====================================================

async function fazerLogout() {

    try {

        await requisicao("/api/logout", {
            method: "POST"
        });

    } catch (erro) {

        console.error(erro);

    }

    localStorage.removeItem("token");
    localStorage.removeItem("email");

    window.location.href = "login.html";

}


// =====================================================
// DATA
// =====================================================

function formatarData(data) {

    if (!data) {
        return "";
    }

    return new Date(data).toLocaleString("pt-BR", {
        dateStyle: "short",
        timeStyle: "short"
    });

}


// =====================================================
// INICIALIZAÇÃO
// =====================================================

console.log("Iniciando funcionalidades...");

carregarCategorias();
carregarTopicos();

console.log("Botão adicionar:", botaoAdicionar);
console.log("Botão notificação:", botaoNotificacao);
console.log("Campo pesquisa:", campoPesquisa);
console.log("Categorias:", listaCategorias);
console.log("Publicações:", listaPublicacoes);