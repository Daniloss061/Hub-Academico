-- Hub Acadêmico - estrutura completa do banco (PostgreSQL)
-- O servidor (server.js) roda este arquivo sozinho ao iniciar,
-- então rodar manualmente no pgAdmin é opcional. É seguro rodar várias vezes.

-- ---------- USUÁRIOS E LOGIN ----------
CREATE TABLE IF NOT EXISTS usuarios (
    id         SERIAL PRIMARY KEY,
    email      VARCHAR(255) NOT NULL UNIQUE,
    senha_hash TEXT NOT NULL,
    criado_em  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Uma linha por login ativo. O navegador guarda o token e envia em cada ação.
CREATE TABLE IF NOT EXISTS sessoes (
    token      TEXT PRIMARY KEY,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    criado_em  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------- CONTEÚDO ----------
CREATE TABLE IF NOT EXISTS categorias (
    id   SERIAL PRIMARY KEY,
    nome VARCHAR(60) NOT NULL UNIQUE
);

INSERT INTO categorias (nome) VALUES
    ('Materiais de estudo'),
    ('Estágios'),
    ('Grupos'),
    ('Eventos'),
    ('Avisos')
ON CONFLICT (nome) DO NOTHING;

-- Tópicos (publicações)
CREATE TABLE IF NOT EXISTS topicos (
    id           SERIAL PRIMARY KEY,
    usuario_id   INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    categoria_id INTEGER NOT NULL REFERENCES categorias(id),
    titulo       VARCHAR(150) NOT NULL,
    conteudo     TEXT NOT NULL,
    criado_em    TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Comentários dentro de um tópico
CREATE TABLE IF NOT EXISTS comentarios (
    id         SERIAL PRIMARY KEY,
    topico_id  INTEGER NOT NULL REFERENCES topicos(id) ON DELETE CASCADE,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    conteudo   TEXT NOT NULL,
    criado_em  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Curtidas (cada usuário curte um tópico no máximo uma vez)
CREATE TABLE IF NOT EXISTS curtidas (
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    topico_id  INTEGER NOT NULL REFERENCES topicos(id) ON DELETE CASCADE,
    criado_em  TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (usuario_id, topico_id)
);

-- Tópicos salvos (o botão 🔖)
CREATE TABLE IF NOT EXISTS salvos (
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    topico_id  INTEGER NOT NULL REFERENCES topicos(id) ON DELETE CASCADE,
    criado_em  TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (usuario_id, topico_id)
);

CREATE INDEX IF NOT EXISTS idx_topicos_categoria   ON topicos (categoria_id);
CREATE INDEX IF NOT EXISTS idx_topicos_criado_em   ON topicos (criado_em DESC);
CREATE INDEX IF NOT EXISTS idx_comentarios_topico  ON comentarios (topico_id);

-- ---------- CONSULTAS ÚTEIS PARA CONFERIR NO PGADMIN ----------
-- SELECT id, email, criado_em FROM usuarios ORDER BY id;
-- SELECT t.id, u.email AS autor, c.nome AS categoria, t.titulo, t.criado_em
--   FROM topicos t JOIN usuarios u ON u.id = t.usuario_id
--   JOIN categorias c ON c.id = t.categoria_id ORDER BY t.id;
-- SELECT cm.id, cm.topico_id, u.email AS autor, cm.conteudo, cm.criado_em
--   FROM comentarios cm JOIN usuarios u ON u.id = cm.usuario_id ORDER BY cm.id;
