const formulario = document.getElementById("formLogin");

formulario.addEventListener("submit", async function(event) {

    event.preventDefault();

    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;
    const mensagem = document.getElementById("mensagem");

    if (email.trim() === "" || senha.trim() === "") {

        mensagem.textContent = "Preencha todos os campos.";

        return;
    }

    try {
        const resposta = await fetch("/api/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, senha })
        });

        const dados = await resposta.json();

        if (!dados.ok) {
            mensagem.textContent = dados.erro;
            return;
        }

        mensagem.textContent = "Login realizado com sucesso!";

        setTimeout(function() {

            window.location.href = "principal.html";

        }, 500);

    } catch (erro) {
        mensagem.textContent = "Não foi possível conectar ao servidor.";
    }

});