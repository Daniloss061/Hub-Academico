require("dotenv").config();

const express = require("express");
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const path = require("path");

const app = express();
const PORTA = process.env.PORT || 3000;

// ---------- BANCO DE DADOS (PostgreSQL) ----------
// Os dados de conexão vêm do arquivo .env (veja o .env.example)
const pool = new Pool({
    host: process.env.DB_HOST || "localhost",
    port: Number(process.env.DB_PORT) || 5432,
    database: process.env.DB_NAME || "hub_academico",
    user: process.env.DB_USER || "postgres",
    password: process.env.DB_PASSWORD
});

async function prepararBanco() {
    await pool.query(`
        CREATE TABLE IF NOT EXISTS usuarios (
            id         SERIAL PRIMARY KEY,
            email      VARCHAR(255) NOT NULL UNIQUE,
            senha_hash TEXT NOT NULL,
            criado_em  TIMESTAMP NOT NULL DEFAULT NOW()
        )
    `);
}

// ---------- ARQUIVOS DO SITE ----------
// Só libera as páginas do projeto (não expõe server.js nem o .env)
const publicos = /^\/(hub|login|cadastro|principal)\.html$|^\/style\.css$|^\/(login|cadastro)\.js$/;

app.use(express.json());

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "hub.html"));
});

app.use((req, res, next) => {
    if (req.method === "GET" && publicos.test(req.path)) {
        return res.sendFile(path.join(__dirname, req.path));
    }
    next();
});

// ---------- ROTAS DA API ----------
const emailValido = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

// Cadastro
app.post("/api/cadastro", async (req, res) => {
    const email = String(req.body.email || "").trim().toLowerCase();
    const senha = String(req.body.senha || "");

    if (!emailValido(email)) {
        return res.status(400).json({ ok: false, erro: "E-mail inválido." });
    }
    if (senha.length < 6) {
        return res.status(400).json({ ok: false, erro: "A senha deve ter pelo menos 6 caracteres." });
    }

    try {
        const senhaHash = await bcrypt.hash(senha, 10);
        await pool.query(
            "INSERT INTO usuarios (email, senha_hash) VALUES ($1, $2)",
            [email, senhaHash]
        );
        res.status(201).json({ ok: true });
    } catch (erro) {
        // 23505 = violação de UNIQUE (e-mail já existe)
        if (erro.code === "23505") {
            return res.status(409).json({ ok: false, erro: "Este e-mail já está cadastrado." });
        }
        console.error(erro);
        res.status(500).json({ ok: false, erro: "Erro interno no servidor." });
    }
});

// Login
app.post("/api/login", async (req, res) => {
    const email = String(req.body.email || "").trim().toLowerCase();
    const senha = String(req.body.senha || "");

    try {
        const resultado = await pool.query(
            "SELECT id, senha_hash FROM usuarios WHERE email = $1",
            [email]
        );
        const usuario = resultado.rows[0];

        if (!usuario || !(await bcrypt.compare(senha, usuario.senha_hash))) {
            return res.status(401).json({ ok: false, erro: "E-mail ou senha incorretos." });
        }

        res.json({ ok: true });
    } catch (erro) {
        console.error(erro);
        res.status(500).json({ ok: false, erro: "Erro interno no servidor." });
    }
});

// ---------- INICIAR ----------
prepararBanco()
    .then(() => {
        app.listen(PORTA, () => {
            console.log(`Banco conectado (${pool.options.database}).`);
            console.log(`Servidor rodando em http://localhost:${PORTA}`);
        });
    })
    .catch((erro) => {
        console.error("Não foi possível conectar ao PostgreSQL:", erro.message);
        console.error("Confira o arquivo .env (usuário, senha, porta e nome do banco) e se o banco foi criado no pgAdmin.");
        process.exit(1);
    });
