const formulario = document.getElementById("formCadastro");

formulario.addEventListener("submit", async function(event) {

    event.preventDefault();

    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;
    const confirmaSenha = document.getElementById("confirmaSenha").value;
    const mensagem = document.getElementById("mensagem");

    if (email.trim() === "" || senha.trim() === "" || confirmaSenha.trim() === "") {
        mensagem.textContent = "Preencha todos os campos.";
        return;
    }

    if (senha !== confirmaSenha) {
        mensagem.textContent = "As senhas não coincidem.";
        return;
    }

    try {
        const resposta = await fetch("/api/cadastro", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, senha })
        });

        const dados = await resposta.json();

        if (!dados.ok) {
            mensagem.textContent = dados.erro;
            return;
        }

        mensagem.textContent = "Conta criada com sucesso!";

        setTimeout(function() {
            window.location.href = "login.html";
        }, 800);

    } catch (erro) {
        mensagem.textContent = "Não foi possível conectar ao servidor.";
    }

});
