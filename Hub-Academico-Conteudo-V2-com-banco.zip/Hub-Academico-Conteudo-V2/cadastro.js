document.getElementById("formCadastro").addEventListener("submit", async function (e) {
    e.preventDefault();
    const msg = document.getElementById("mensagemCadastro");

    const nome = document.getElementById("nome").value.trim();
    const email = document.getElementById("emailCadastro").value.trim();
    const senha = document.getElementById("senhaCadastro").value;

    try {
        await Hub.api("/api/cadastro", {
            method: "POST",
            body: JSON.stringify({ nome, email, senha })
        });
        msg.textContent = "Conta criada com sucesso! Agora você pode entrar.";
        setTimeout(function () { location.href = "login.html"; }, 900);
    } catch (erro) {
        msg.textContent = erro.message === "Failed to fetch"
            ? "Não foi possível conectar ao servidor."
            : erro.message;
    }
});
