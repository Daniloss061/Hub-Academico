const termo = (new URLSearchParams(location.search).get("busca") || "").trim();
document.getElementById("campoBusca").value = termo;

const lista = document.getElementById("resultados");
const resumo = document.getElementById("resultadoBusca");

async function buscar() {
    try {
        const d = await Hub.api("/api/topicos" + (termo ? "?busca=" + encodeURIComponent(termo) : ""));
        Hub.mostrarLista(lista, d.topicos, termo ? "Nenhum resultado encontrado para essa busca." : "Ainda não há publicações para explorar.", buscar);
        resumo.textContent = termo && d.topicos.length ? d.topicos.length + " resultado(s) encontrado(s)." : "";
    } catch (erro) {
        resumo.textContent = erro.message;
    }
}
buscar();
