if (Hub.exigirLogin()) {
    const lista = document.getElementById("listaSalvos");
    async function carregar() {
        try {
            const d = await Hub.api("/api/salvos");
            Hub.mostrarLista(lista, d.salvos, "🔖 Nenhum item salvo por enquanto. Toque em 🔖 numa publicação para guardá-la aqui.", carregar);
        } catch (erro) {
            lista.replaceChildren(Hub.el("div", "estado-vazio", erro.message));
        }
    }
    carregar();
}
