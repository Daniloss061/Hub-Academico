# Hub Acadêmico

Informação, conhecimento e oportunidade em um só lugar.

## Como rodar

1. Instale o Node.js (versão LTS) e o PostgreSQL.
2. No pgAdmin, crie um banco chamado `hub_academico`.
3. Copie o `.env.example` para `.env` e coloque a senha do seu PostgreSQL em `DB_PASSWORD`.
4. No terminal, dentro desta pasta:

```
npm install
npm start
```

5. Abra http://localhost:3000

As tabelas são criadas sozinhas na primeira vez (veja `banco.sql`).

> No PowerShell do Windows, se o `npm` for bloqueado, use `npm.cmd install` e `npm.cmd start`.

## Estrutura

| Arquivo | Função |
|---|---|
| `hub.html` | tela inicial (Entrar / Criar Conta) |
| `cadastro.html`, `cadastro.js` | criar conta (nome, e-mail, senha) |
| `login.html`, `login.js` | entrar |
| `principal.html`, `principal.js` | feed com as publicações do banco |
| `nova-publicacao.html`, `nova-publicacao.js` | criar publicação |
| `explorar.html`, `explorar.js` | busca no banco |
| `materiais`, `estagios`, `grupos`, `eventos` `.html` + `categoria.js` | publicações de cada categoria |
| `salvos.html`, `salvos.js` | publicações salvas |
| `perfil.html`, `editar-perfil.html` (+ `.js`) | perfil, sair da conta |
| `api.js` | funções compartilhadas (chamadas à API, cartão de publicação) |
| `style.css` | estilos de todas as telas |
| `server.js` | servidor e rotas da API |
| `banco.sql` | estrutura do banco de dados |

## API

| Ação | Rota | Login |
|---|---|---|
| Cadastro | `POST /api/cadastro` (`nome`, `email`, `senha`) | não |
| Login (devolve o token) | `POST /api/login` | não |
| Logout | `POST /api/logout` | sim |
| Categorias | `GET /api/categorias` | não |
| Listar tópicos | `GET /api/topicos` (`?categoria=ID`, `?busca=texto`) | não |
| Ver tópico + comentários | `GET /api/topicos/:id` | não |
| Criar tópico | `POST /api/topicos` (`titulo`, `conteudo`, `categoria_id`) | sim |
| Comentar | `POST /api/topicos/:id/comentarios` (`conteudo`) | sim |
| Curtir / descurtir | `POST /api/topicos/:id/curtir` | sim |
| Salvar / desfazer | `POST /api/topicos/:id/salvar` | sim |
| Meus salvos | `GET /api/salvos` | sim |
| Ver / editar meu perfil | `GET /api/perfil`, `PUT /api/perfil` (`nome`, `bio`) | sim |
| Apagar tópico / comentário (só o autor) | `DELETE /api/topicos/:id`, `DELETE /api/comentarios/:id` | sim |

Rotas com login exigem o cabeçalho `Authorization: Bearer <token>`.
Depois do login, o token fica em `localStorage.getItem("token")`.
