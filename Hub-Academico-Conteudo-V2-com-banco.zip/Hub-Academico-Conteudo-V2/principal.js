const lista = document.getElementById("listaFeed");

async function carregarFeed() {
    try {
        const d = await Hub.api("/api/topicos");
        Hub.mostrarLista(lista, d.topicos, "Nenhuma publicação ainda. Toque no + para criar a primeira!", carregarFeed);
    } catch (erro) {
        lista.replaceChildren(Hub.el("div", "estado-vazio", "Não foi possível carregar as publicações."));
    }
}

carregarFeed();
