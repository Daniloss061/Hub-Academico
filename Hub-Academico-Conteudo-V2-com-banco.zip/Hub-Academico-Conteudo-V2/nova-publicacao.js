if (Hub.exigirLogin()) {
    const select = document.getElementById("categoriaPost");
    const msg = document.getElementById("msgPost");

    // Categorias vêm do banco
    Hub.api("/api/categorias").then(function (d) {
        select.replaceChildren();
        d.categorias.forEach(function (c) {
            const o = document.createElement("option");
            o.value = c.id;
            o.textContent = c.nome;
            select.append(o);
        });
    }).catch(function () {
        select.replaceChildren(new Option("Erro ao carregar categorias", ""));
    });

    document.getElementById("formPublicacao").addEventListener("submit", async function (e) {
        e.preventDefault();
        msg.className = "mensagem-pagina";
        try {
            await Hub.api("/api/topicos", {
                method: "POST",
                body: JSON.stringify({
                    titulo: document.getElementById("tituloPost").value,
                    conteudo: document.getElementById("textoPost").value,
                    categoria_id: Number(select.value)
                })
            });
            msg.textContent = "Publicação criada!";
            setTimeout(function () { location.href = "confirmacao.html"; }, 600);
        } catch (erro) {
            msg.className = "erro-pagina";
            msg.textContent = erro.message;
        }
    });
}
