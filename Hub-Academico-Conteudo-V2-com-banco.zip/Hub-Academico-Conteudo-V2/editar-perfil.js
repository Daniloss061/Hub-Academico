if (Hub.exigirLogin()) {
    const msg = document.getElementById("msgPerfil");

    Hub.api("/api/perfil").then(function (d) {
        document.getElementById("nomePerfil").value = d.perfil.nome;
        document.getElementById("bioPerfil").value = d.perfil.bio;
    }).catch(function (erro) { msg.className = "erro-pagina"; msg.textContent = erro.message; });

    document.getElementById("formPerfil").addEventListener("submit", async function (e) {
        e.preventDefault();
        msg.className = "mensagem-pagina";
        try {
            const d = await Hub.api("/api/perfil", {
                method: "PUT",
                body: JSON.stringify({
                    nome: document.getElementById("nomePerfil").value,
                    bio: document.getElementById("bioPerfil").value
                })
            });
            localStorage.setItem("nome", d.nome);
            msg.textContent = "Alterações salvas!";
        } catch (erro) {
            msg.className = "erro-pagina";
            msg.textContent = erro.message;
        }
    });
}
