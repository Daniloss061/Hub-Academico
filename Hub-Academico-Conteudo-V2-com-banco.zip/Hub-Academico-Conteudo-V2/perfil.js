if (Hub.exigirLogin()) {
    document.getElementById("sair").addEventListener("click", function (e) {
        e.preventDefault();
        Hub.sair();
    });

    Hub.api("/api/perfil").then(function (d) {
        const p = d.perfil;
        const nome = p.nome || p.email.split("@")[0];
        document.getElementById("avatarPerfil").textContent = Hub.iniciais(nome);
        document.getElementById("nomePerfil").textContent = nome;
        document.getElementById("emailPerfil").textContent = p.email;
        document.getElementById("bioPerfil").textContent = p.bio;
        document.getElementById("contagemPerfil").textContent = p.publicacoes + " publicação(ões) · " + p.salvos + " salvo(s)";
    }).catch(function (erro) {
        document.getElementById("emailPerfil").textContent = erro.message;
    });
}
