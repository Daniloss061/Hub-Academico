// Páginas Materiais / Estágios / Grupos / Eventos: mostram as publicações da categoria (data-categoria no <body>)
const nomeCategoria = document.body.dataset.categoria;
const lista = document.getElementById("listaCategoria");

async function carregar() {
    try {
        const cats = await Hub.api("/api/categorias");
        const cat = cats.categorias.find((c) => c.nome === nomeCategoria);
        if (!cat) throw new Error("Categoria não encontrada.");
        const d = await Hub.api("/api/topicos?categoria=" + cat.id);
        Hub.mostrarLista(lista, d.topicos, "Ainda não há publicações nesta categoria.", carregar);
    } catch (erro) {
        lista.replaceChildren(Hub.el("div", "estado-vazio", erro.message));
    }
}
carregar();
