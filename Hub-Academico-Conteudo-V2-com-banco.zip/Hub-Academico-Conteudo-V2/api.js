// Funções compartilhadas por todas as telas: chamadas à API, sessão e cartões de publicação.
// Sempre use textContent (nunca innerHTML) com texto vindo do banco, para evitar injeção de HTML.

const Hub = (function () {
    const token = localStorage.getItem("token");

    async function api(url, opcoes = {}) {
        const resposta = await fetch(url, {
            ...opcoes,
            headers: {
                "Content-Type": "application/json",
                ...(opcoes.headers || {}),
                ...(token ? { Authorization: "Bearer " + token } : {})
            }
        });

        let dados;
        try {
            dados = await resposta.json();
        } catch {
            throw new Error("Resposta inválida do servidor.");
        }

        if (resposta.status === 401 && token) {
            sairLocal();
            window.location.href = "login.html";
            throw new Error(dados.erro || "Sessão expirada.");
        }
        if (!resposta.ok || dados.ok === false) {
            throw new Error(dados.erro || "Ocorreu um erro.");
        }
        return dados;
    }

    function sairLocal() {
        ["token", "email", "nome"].forEach((k) => localStorage.removeItem(k));
    }

    async function sair() {
        try { await api("/api/logout", { method: "POST" }); } catch (e) { /* segue mesmo assim */ }
        sairLocal();
        window.location.href = "login.html";
    }

    // Páginas que só funcionam logado chamam isto no começo
    function exigirLogin() {
        if (!token) {
            window.location.href = "login.html";
            return false;
        }
        return true;
    }

    function formatarData(data) {
        return data ? new Date(data).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "";
    }

    function el(tag, classe, texto) {
        const e = document.createElement(tag);
        if (classe) e.className = classe;
        if (texto !== undefined) e.textContent = texto;
        return e;
    }

    function iniciais(nome) {
        const p = String(nome).trim().split(/\s+/);
        return ((p[0] || "?")[0] + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase();
    }

    // Monta o cartão de uma publicação (curtir, comentar, salvar, apagar)
    // aoMudar(): chamado depois de apagar/desfazer salvo para a página recarregar a lista
    function cartao(topico, aoMudar) {
        const art = el("article", "publicacao");

        const usuario = el("div", "usuario");
        usuario.append(el("div", "avatar", iniciais(topico.autor)));
        const quem = el("div");
        quem.append(el("strong", null, topico.autor), el("small", null, formatarData(topico.criado_em)));
        usuario.append(quem);
        if (topico.meu) {
            const apagar = el("button", "mais botao-icone", "🗑");
            apagar.type = "button";
            apagar.title = "Apagar publicação";
            apagar.addEventListener("click", async () => {
                if (!confirm("Apagar esta publicação?")) return;
                try {
                    await api("/api/topicos/" + topico.id, { method: "DELETE" });
                    if (aoMudar) aoMudar();
                } catch (e) { alert(e.message); }
            });
            usuario.append(apagar);
        }
        art.append(usuario);

        art.append(el("span", "categoria-post", topico.categoria));
        art.append(el("h3", null, topico.titulo));
        art.append(el("p", null, topico.conteudo));

        const acoes = el("div", "acoes");
        const bCurtir = el("button", "botao-acao");
        const bComent = el("button", "botao-acao");
        const bSalvar = el("button", "botao-acao");
        [bCurtir, bComent, bSalvar].forEach((b) => (b.type = "button"));

        const pintar = () => {
            bCurtir.textContent = (topico.curtido ? "♥ " : "♡ ") + topico.curtidas;
            bCurtir.classList.toggle("ativo", !!topico.curtido);
            bComent.textContent = "💬 " + topico.comentarios;
            bSalvar.textContent = topico.salvo ? "🔖 Salvo" : "🔖";
            bSalvar.classList.toggle("ativo", !!topico.salvo);
        };
        pintar();

        bCurtir.addEventListener("click", async () => {
            if (!token) return alert("Faça login para curtir uma publicação.");
            try {
                const r = await api("/api/topicos/" + topico.id + "/curtir", { method: "POST" });
                topico.curtidas += r.curtido ? 1 : -1;
                topico.curtido = r.curtido;
                pintar();
            } catch (e) { alert(e.message); }
        });

        bSalvar.addEventListener("click", async () => {
            if (!token) return alert("Faça login para salvar uma publicação.");
            try {
                const r = await api("/api/topicos/" + topico.id + "/salvar", { method: "POST" });
                topico.salvo = r.salvo;
                pintar();
                if (!r.salvo && aoMudar && document.body.dataset.pagina === "salvos") aoMudar();
            } catch (e) { alert(e.message); }
        });

        acoes.append(bCurtir, bComent, bSalvar);
        art.append(acoes);

        // Comentários (abre/fecha ao clicar no 💬)
        const area = el("div", "comentarios-area");
        area.hidden = true;
        art.append(area);

        async function carregarComentarios() {
            area.replaceChildren(el("small", null, "Carregando..."));
            try {
                const d = await api("/api/topicos/" + topico.id);
                topico.comentarios = d.comentarios.length;
                pintar();
                area.replaceChildren();
                d.comentarios.forEach((c) => {
                    const linha = el("div", "comentario");
                    const cab = el("strong", null, c.autor);
                    const data = el("small", null, " · " + formatarData(c.criado_em));
                    linha.append(cab, data);
                    if (c.meu) {
                        const x = el("button", "botao-icone", "✕");
                        x.type = "button";
                        x.title = "Apagar comentário";
                        x.addEventListener("click", async () => {
                            try {
                                await api("/api/comentarios/" + c.id, { method: "DELETE" });
                                carregarComentarios();
                            } catch (e) { alert(e.message); }
                        });
                        linha.append(x);
                    }
                    linha.append(el("p", null, c.conteudo));
                    area.append(linha);
                });
                if (d.comentarios.length === 0) area.append(el("small", null, "Seja o primeiro a comentar."));

                if (token) {
                    const form = el("form", "form-comentario");
                    const campo = el("input");
                    campo.placeholder = "Escreva um comentário...";
                    campo.maxLength = 1000;
                    campo.required = true;
                    const envia = el("button", null, "Enviar");
                    envia.type = "submit";
                    form.append(campo, envia);
                    form.addEventListener("submit", async (ev) => {
                        ev.preventDefault();
                        try {
                            await api("/api/topicos/" + topico.id + "/comentarios", {
                                method: "POST",
                                body: JSON.stringify({ conteudo: campo.value })
                            });
                            carregarComentarios();
                        } catch (e) { alert(e.message); }
                    });
                    area.append(form);
                } else {
                    area.append(el("small", null, "Faça login para comentar."));
                }
            } catch (e) {
                area.replaceChildren(el("small", null, e.message));
            }
        }

        bComent.addEventListener("click", () => {
            area.hidden = !area.hidden;
            if (!area.hidden) carregarComentarios();
        });

        return art;
    }

    // Preenche um container com a lista de publicações
    function mostrarLista(container, topicos, vazio, aoMudar) {
        container.replaceChildren();
        if (topicos.length === 0) {
            container.append(el("div", "estado-vazio", vazio));
            return;
        }
        topicos.forEach((t) => container.append(cartao(t, aoMudar)));
    }

    return { api, token, sair, sairLocal, exigirLogin, formatarData, el, iniciais, cartao, mostrarLista };
})();
