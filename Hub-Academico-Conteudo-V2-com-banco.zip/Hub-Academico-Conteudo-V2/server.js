require("dotenv").config();

const express = require("express");
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORTA = process.env.PORT || 3000;

// ---------- BANCO DE DADOS (PostgreSQL) ----------
// Os dados de conexão vêm do arquivo .env (veja o .env.example)
const pool = new Pool({
    host: process.env.DB_HOST || "localhost",
    port: Number(process.env.DB_PORT) || 5432,
    database: process.env.DB_NAME || "hub_academico",
    user: process.env.DB_USER || "postgres",
    password: process.env.DB_PASSWORD
});

// Cria todas as tabelas lendo o banco.sql (seguro rodar várias vezes)
async function prepararBanco() {
    const sql = fs.readFileSync(path.join(__dirname, "banco.sql"), "utf8");
    await pool.query(sql);
}

// ---------- ARQUIVOS DO SITE ----------
// Só libera páginas .html, o style.css e os .js do navegador (não expõe server.js, banco.sql nem o .env)
const publicos = /^\/[a-z0-9-]+\.html$|^\/style\.css$|^\/(?!server\.js$)[a-z0-9-]+\.js$/;

app.use(express.json());

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "hub.html"));
});

app.use((req, res, next) => {
    if (req.method === "GET" && publicos.test(req.path)) {
        return res.sendFile(path.join(__dirname, req.path));
    }
    next();
});

// ---------- FUNÇÕES AUXILIARES ----------
const emailValido = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

const erro500 = (res, erro) => {
    console.error(erro);
    res.status(500).json({ ok: false, erro: "Erro interno no servidor." });
};

// Lê o id da URL (/:id). Devolve null se não for um número válido.
const lerId = (valor) => {
    const n = Number(valor);
    return Number.isInteger(n) && n > 0 && n < 2147483647 ? n : null;
};

// Nome mostrado nas publicações: o nome cadastrado ou, se não tiver, a parte do e-mail antes do @
const NOME_EXIBICAO = (alias) => `COALESCE(NULLIF(${alias}.nome, ''), split_part(${alias}.email, '@', 1))`;

// Lê o token se existir, mas não bloqueia quem não está logado
async function loginOpcional(req, res, next) {
    const cabecalho = req.headers.authorization || "";
    const token = cabecalho.startsWith("Bearer ") ? cabecalho.slice(7) : "";
    req.usuario = null;
    if (!token) return next();
    try {
        const r = await pool.query(
            `SELECT u.id, u.email
               FROM sessoes s JOIN usuarios u ON u.id = s.usuario_id
              WHERE s.token = $1`,
            [token]
        );
        if (r.rowCount > 0) req.usuario = r.rows[0];
        next();
    } catch (erro) {
        erro500(res, erro);
    }
}

// Exige login: o navegador envia "Authorization: Bearer <token>"
async function exigirLogin(req, res, next) {
    const cabecalho = req.headers.authorization || "";
    const token = cabecalho.startsWith("Bearer ") ? cabecalho.slice(7) : "";

    if (!token) {
        return res.status(401).json({ ok: false, erro: "Faça login para continuar." });
    }

    try {
        const r = await pool.query(
            `SELECT u.id, u.email
               FROM sessoes s JOIN usuarios u ON u.id = s.usuario_id
              WHERE s.token = $1`,
            [token]
        );
        if (r.rowCount === 0) {
            return res.status(401).json({ ok: false, erro: "Sessão inválida. Faça login de novo." });
        }
        req.usuario = r.rows[0];
        req.token = token;
        next();
    } catch (erro) {
        erro500(res, erro);
    }
}

// ---------- CADASTRO E LOGIN ----------
app.post("/api/cadastro", async (req, res) => {
    const nome = String(req.body.nome || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const senha = String(req.body.senha || "");

    if (nome.length < 2 || nome.length > 100) {
        return res.status(400).json({ ok: false, erro: "Informe seu nome (2 a 100 caracteres)." });
    }
    if (!emailValido(email)) {
        return res.status(400).json({ ok: false, erro: "E-mail inválido." });
    }
    if (senha.length < 6) {
        return res.status(400).json({ ok: false, erro: "A senha deve ter pelo menos 6 caracteres." });
    }

    try {
        const senhaHash = await bcrypt.hash(senha, 10);
        await pool.query(
            "INSERT INTO usuarios (nome, email, senha_hash) VALUES ($1, $2, $3)",
            [nome, email, senhaHash]
        );
        res.status(201).json({ ok: true });
    } catch (erro) {
        // 23505 = violação de UNIQUE (e-mail já existe)
        if (erro.code === "23505") {
            return res.status(409).json({ ok: false, erro: "Este e-mail já está cadastrado." });
        }
        erro500(res, erro);
    }
});

app.post("/api/login", async (req, res) => {
    const email = String(req.body.email || "").trim().toLowerCase();
    const senha = String(req.body.senha || "");

    try {
        const resultado = await pool.query(
            "SELECT id, nome, senha_hash FROM usuarios WHERE email = $1",
            [email]
        );
        const usuario = resultado.rows[0];

        if (!usuario || !(await bcrypt.compare(senha, usuario.senha_hash))) {
            return res.status(401).json({ ok: false, erro: "E-mail ou senha incorretos." });
        }

        // Cria a sessão: o token fica salvo no banco e o navegador guarda uma cópia
        const token = crypto.randomBytes(32).toString("hex");
        await pool.query(
            "INSERT INTO sessoes (token, usuario_id) VALUES ($1, $2)",
            [token, usuario.id]
        );

        res.json({ ok: true, token, email, nome: usuario.nome || email.split("@")[0] });
    } catch (erro) {
        erro500(res, erro);
    }
});

app.post("/api/logout", exigirLogin, async (req, res) => {
    try {
        await pool.query("DELETE FROM sessoes WHERE token = $1", [req.token]);
        res.json({ ok: true });
    } catch (erro) {
        erro500(res, erro);
    }
});

// ---------- CATEGORIAS ----------
app.get("/api/categorias", async (req, res) => {
    try {
        const r = await pool.query("SELECT id, nome FROM categorias ORDER BY id");
        res.json({ ok: true, categorias: r.rows });
    } catch (erro) {
        erro500(res, erro);
    }
});

// ---------- TÓPICOS ----------
// Consulta base dos tópicos. $1 = id do usuário logado (ou NULL) para marcar curtido/salvo.
const SELECT_TOPICOS = `
    SELECT t.id, t.titulo, t.conteudo, t.criado_em,
           c.id AS categoria_id, c.nome AS categoria,
           ${NOME_EXIBICAO("u")} AS autor,
           (t.usuario_id = $1) AS meu,
           (SELECT COUNT(*) FROM curtidas    WHERE topico_id = t.id)::int AS curtidas,
           (SELECT COUNT(*) FROM comentarios WHERE topico_id = t.id)::int AS comentarios,
           EXISTS (SELECT 1 FROM curtidas WHERE topico_id = t.id AND usuario_id = $1) AS curtido,
           EXISTS (SELECT 1 FROM salvos   WHERE topico_id = t.id AND usuario_id = $1) AS salvo
      FROM topicos t
      JOIN usuarios   u ON u.id = t.usuario_id
      JOIN categorias c ON c.id = t.categoria_id`;

// Lista os tópicos mais recentes (opcional: ?categoria=ID e ?busca=texto)
app.get("/api/topicos", loginOpcional, async (req, res) => {
    const categoriaId = req.query.categoria ? lerId(req.query.categoria) : null;
    if (req.query.categoria && !categoriaId) {
        return res.status(400).json({ ok: false, erro: "Categoria inválida." });
    }
    const busca = String(req.query.busca || "").trim().slice(0, 100);
    // escapa % _ \ para a busca ser literal
    const padrao = busca ? "%" + busca.replace(/[\\%_]/g, "\\$&") + "%" : null;

    try {
        const r = await pool.query(
            `${SELECT_TOPICOS}
              WHERE ($2::int IS NULL OR t.categoria_id = $2)
                AND ($3::text IS NULL OR t.titulo ILIKE $3 OR t.conteudo ILIKE $3
                     OR c.nome ILIKE $3 OR ${NOME_EXIBICAO("u")} ILIKE $3)
              ORDER BY t.criado_em DESC, t.id DESC
              LIMIT 50`,
            [req.usuario ? req.usuario.id : null, categoriaId, padrao]
        );
        res.json({ ok: true, topicos: r.rows });
    } catch (erro) {
        erro500(res, erro);
    }
});

// Um tópico com todos os comentários
app.get("/api/topicos/:id", loginOpcional, async (req, res) => {
    const id = lerId(req.params.id);
    if (!id) return res.status(400).json({ ok: false, erro: "Tópico inválido." });
    const meuId = req.usuario ? req.usuario.id : null;

    try {
        const t = await pool.query(`${SELECT_TOPICOS} WHERE t.id = $2`, [meuId, id]);
        if (t.rowCount === 0) {
            return res.status(404).json({ ok: false, erro: "Tópico não encontrado." });
        }

        const cm = await pool.query(
            `SELECT cm.id, cm.conteudo, cm.criado_em,
                    ${NOME_EXIBICAO("u")} AS autor,
                    (cm.usuario_id = $2) AS meu
               FROM comentarios cm JOIN usuarios u ON u.id = cm.usuario_id
              WHERE cm.topico_id = $1
              ORDER BY cm.criado_em, cm.id`,
            [id, meuId]
        );

        res.json({ ok: true, topico: t.rows[0], comentarios: cm.rows });
    } catch (erro) {
        erro500(res, erro);
    }
});

// Criar tópico (precisa estar logado)
app.post("/api/topicos", exigirLogin, async (req, res) => {
    const titulo = String(req.body.titulo || "").trim();
    const conteudo = String(req.body.conteudo || "").trim();
    const categoriaId = lerId(req.body.categoria_id);

    if (titulo.length < 3 || titulo.length > 150) {
        return res.status(400).json({ ok: false, erro: "O título deve ter entre 3 e 150 caracteres." });
    }
    if (conteudo.length < 1 || conteudo.length > 5000) {
        return res.status(400).json({ ok: false, erro: "O conteúdo deve ter entre 1 e 5000 caracteres." });
    }
    if (!categoriaId) {
        return res.status(400).json({ ok: false, erro: "Escolha uma categoria." });
    }

    try {
        const r = await pool.query(
            `INSERT INTO topicos (usuario_id, categoria_id, titulo, conteudo)
             VALUES ($1, $2, $3, $4) RETURNING id`,
            [req.usuario.id, categoriaId, titulo, conteudo]
        );
        res.status(201).json({ ok: true, id: r.rows[0].id });
    } catch (erro) {
        // 23503 = categoria que não existe
        if (erro.code === "23503") {
            return res.status(400).json({ ok: false, erro: "Categoria não encontrada." });
        }
        erro500(res, erro);
    }
});

// Apagar tópico (só o autor)
app.delete("/api/topicos/:id", exigirLogin, async (req, res) => {
    const id = lerId(req.params.id);
    if (!id) return res.status(400).json({ ok: false, erro: "Tópico inválido." });

    try {
        const r = await pool.query(
            "DELETE FROM topicos WHERE id = $1 AND usuario_id = $2",
            [id, req.usuario.id]
        );
        if (r.rowCount === 0) {
            return res.status(404).json({ ok: false, erro: "Tópico não encontrado ou não é seu." });
        }
        res.json({ ok: true });
    } catch (erro) {
        erro500(res, erro);
    }
});

// ---------- COMENTÁRIOS ----------
app.post("/api/topicos/:id/comentarios", exigirLogin, async (req, res) => {
    const topicoId = lerId(req.params.id);
    const conteudo = String(req.body.conteudo || "").trim();

    if (!topicoId) return res.status(400).json({ ok: false, erro: "Tópico inválido." });
    if (conteudo.length < 1 || conteudo.length > 1000) {
        return res.status(400).json({ ok: false, erro: "O comentário deve ter entre 1 e 1000 caracteres." });
    }

    try {
        const r = await pool.query(
            `INSERT INTO comentarios (topico_id, usuario_id, conteudo)
             VALUES ($1, $2, $3) RETURNING id`,
            [topicoId, req.usuario.id, conteudo]
        );
        res.status(201).json({ ok: true, id: r.rows[0].id });
    } catch (erro) {
        if (erro.code === "23503") {
            return res.status(404).json({ ok: false, erro: "Tópico não encontrado." });
        }
        erro500(res, erro);
    }
});

// Apagar comentário (só o autor)
app.delete("/api/comentarios/:id", exigirLogin, async (req, res) => {
    const id = lerId(req.params.id);
    if (!id) return res.status(400).json({ ok: false, erro: "Comentário inválido." });

    try {
        const r = await pool.query(
            "DELETE FROM comentarios WHERE id = $1 AND usuario_id = $2",
            [id, req.usuario.id]
        );
        if (r.rowCount === 0) {
            return res.status(404).json({ ok: false, erro: "Comentário não encontrado ou não é seu." });
        }
        res.json({ ok: true });
    } catch (erro) {
        erro500(res, erro);
    }
});

// ---------- CURTIR E SALVAR (clicar de novo desfaz) ----------
function alternar(tabela, rotulo) {
    return async (req, res) => {
        const topicoId = lerId(req.params.id);
        if (!topicoId) return res.status(400).json({ ok: false, erro: "Tópico inválido." });

        try {
            const existe = await pool.query(
                `SELECT 1 FROM ${tabela} WHERE usuario_id = $1 AND topico_id = $2`,
                [req.usuario.id, topicoId]
            );

            if (existe.rowCount > 0) {
                await pool.query(
                    `DELETE FROM ${tabela} WHERE usuario_id = $1 AND topico_id = $2`,
                    [req.usuario.id, topicoId]
                );
                return res.json({ ok: true, [rotulo]: false });
            }

            await pool.query(
                `INSERT INTO ${tabela} (usuario_id, topico_id) VALUES ($1, $2)`,
                [req.usuario.id, topicoId]
            );
            res.json({ ok: true, [rotulo]: true });
        } catch (erro) {
            if (erro.code === "23503") {
                return res.status(404).json({ ok: false, erro: "Tópico não encontrado." });
            }
            erro500(res, erro);
        }
    };
}

app.post("/api/topicos/:id/curtir", exigirLogin, alternar("curtidas", "curtido"));
app.post("/api/topicos/:id/salvar", exigirLogin, alternar("salvos", "salvo"));

// Tópicos que o usuário logado salvou
app.get("/api/salvos", exigirLogin, async (req, res) => {
    try {
        const r = await pool.query(
            `${SELECT_TOPICOS}
              JOIN salvos s ON s.topico_id = t.id AND s.usuario_id = $1
              ORDER BY s.criado_em DESC`,
            [req.usuario.id]
        );
        res.json({ ok: true, salvos: r.rows });
    } catch (erro) {
        erro500(res, erro);
    }
});

// ---------- PERFIL ----------
app.get("/api/perfil", exigirLogin, async (req, res) => {
    try {
        const r = await pool.query(
            `SELECT u.email, COALESCE(u.nome, '') AS nome, COALESCE(u.bio, '') AS bio, u.criado_em,
                    (SELECT COUNT(*) FROM topicos WHERE usuario_id = u.id)::int AS publicacoes,
                    (SELECT COUNT(*) FROM salvos  WHERE usuario_id = u.id)::int AS salvos
               FROM usuarios u WHERE u.id = $1`,
            [req.usuario.id]
        );
        res.json({ ok: true, perfil: r.rows[0] });
    } catch (erro) {
        erro500(res, erro);
    }
});

app.put("/api/perfil", exigirLogin, async (req, res) => {
    const nome = String(req.body.nome || "").trim();
    const bio = String(req.body.bio || "").trim();

    if (nome.length < 2 || nome.length > 100) {
        return res.status(400).json({ ok: false, erro: "O nome deve ter entre 2 e 100 caracteres." });
    }
    if (bio.length > 300) {
        return res.status(400).json({ ok: false, erro: "O texto sobre você deve ter até 300 caracteres." });
    }

    try {
        await pool.query("UPDATE usuarios SET nome = $1, bio = $2 WHERE id = $3", [nome, bio, req.usuario.id]);
        res.json({ ok: true, nome });
    } catch (erro) {
        erro500(res, erro);
    }
});

// ---------- INICIAR ----------
prepararBanco()
    .then(() => {
        app.listen(PORTA, () => {
            console.log(`Banco conectado (${pool.options.database}).`);
            console.log(`Servidor rodando em http://localhost:${PORTA}`);
        });
    })
    .catch((erro) => {
        console.error("Não foi possível preparar o PostgreSQL:", erro.message);
        console.error("Confira o arquivo .env (usuário, senha, porta e nome do banco) e se o banco foi criado no pgAdmin.");
        process.exit(1);
    });
